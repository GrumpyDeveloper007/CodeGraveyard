#include "windows.h"
#include <stdio.h>

void abc(char *p)
{ FILE *fp=fopen("z.txt","a+");
fprintf(fp,"%s\n",p);
fclose(fp);}

struct o
{
unsigned char Ttl;unsigned char a[7];
};
struct
{
DWORD Address;
unsigned long  Status,RoundTripTime;
unsigned char a[8];
struct o  Options;
} E;

HANDLE hIP;WSADATA wsa;HANDLE hIcmp;DWORD *dwIPAddr;struct hostent *phostent;
DWORD d;char aa[100];struct o I;char bb[100];int z;

HANDLE ( WINAPI *pIcmpCreateFile )( VOID );
BOOL ( WINAPI *pIcmpCloseHandle )( HANDLE );
DWORD (WINAPI *pIcmpSendEcho)(HANDLE,DWORD,LPVOID,WORD,LPVOID,LPVOID,DWORD,DWORD);

int APIENTRY WinMain( HINSTANCE hInstance, HINSTANCE hPrev,
                                        LPSTR lpCmd,int nShow )
{
hIcmp = LoadLibrary( "ICMP.DLL" );
WSAStartup( 0x0101, &wsa );  
pIcmpCreateFile=GetProcAddress( hIcmp,"IcmpCreateFile");
pIcmpCloseHandle=GetProcAddress( hIcmp,"IcmpCloseHandle");
pIcmpSendEcho =GetProcAddress( hIcmp,"IcmpSendEcho" );
hIP = pIcmpCreateFile();

for ( z = 1; z<= 20 ; z++)
{
I.Ttl=(unsigned char)z;
phostent = gethostbyname( "www.neca.com");
dwIPAddr = (DWORD *)( *phostent->h_addr_list );
pIcmpSendEcho(hIP,*dwIPAddr,0,0,&I,&E,sizeof(E),8000 );
d=E.Address;
phostent = gethostbyaddr((char *)&d,4,PF_INET);
if ( phostent != 0) 
        strcpy(aa,phostent->h_name)  ;
else 
        strcpy(aa,"no host name");
wsprintf(bb," RTT: %dms,  TTL: %d",E.RoundTripTime,E.Options.Ttl );
strcat(aa,bb);
abc(aa);
if ( E.Options.Ttl )
        break;
}
MessageBox(0,"over","hi",0);
pIcmpCloseHandle( hIP );
FreeLibrary( hIcmp );
WSACleanup();                                       
}

