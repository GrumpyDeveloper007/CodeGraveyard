
#include <windows.h>
#include <winsock.h>
#include <stdio.h>
void abc(char *p)
{       FILE *fp=fopen("z.txt","a+");
        fprintf(fp,"%s\n",p);
        fclose(fp);
}
WNDCLASS a;HWND b;MSG c;char aa[200];char bb[20000];
long _stdcall zzz (HWND,UINT,WPARAM,LPARAM);
int _stdcall WinMain(HINSTANCE i,HINSTANCE j,char *k,int l)
{
        a.lpszClassName="a1";
        a.hInstance=i;
        a.lpfnWndProc=zzz;
        a.hbrBackground=GetStockObject(WHITE_BRUSH);
        RegisterClass(&a);
        b=CreateWindow("a1","aaa",WS_OVERLAPPEDWINDOW,1,1,10,20,0,0,i,0);
        ShowWindow(b,3);
        while ( GetMessage(&c,0,0,0) )
                DispatchMessage(&c);
        return 1;
}
WSADATA ws;SOCKET s,s1,s2;sockaddr_in A,A1;int d,d1=200;
long _stdcall zzz (HWND w,UINT x,WPARAM y,LPARAM z)
{
        if ( x == WM_USER+1)
        {
        if ( LOWORD(z)&FD_ACCEPT == FD_ACCEPT)
        {
            d=sizeof(A1);
            s1=accept(s,(struct sockaddr *) &A1,&d);
            sprintf(aa,"accept s1 %ld",s1);
            abc(aa);
        }
        if(LOWORD(z)&FD_READ == FD_READ)
        {
            d=recv(y,bb,2000,0);
            sprintf(aa,"recv %ld",d);
            abc(bb);
            strcpy(aa,"HTTP/1.0 200 OK\r\n" );
            strcat(aa,"Date: Sunday Sun, 21 Oct 1995 19:38:46 GMT\r\n");
            strcat(aa,"Server: Webster/1.0\r\n");
            strcat(aa,"MIME-version: 1.0\r\n");
            strcat(aa,"Content-type: text/plain\r\n");
            strcat(aa,"Last-modified: Sunday Sun, 21 Oct 1995 19:38:46 GMT\r\n");
            strcat(aa,"Content-length: 1000\r\n\r\n");
            strcat(aa,"<html>Hello<hr><hr><hi>");
            d=send(y,bb,strlen(bb),0);
            sprintf(aa,"send %ld",d);
            abc(bb);
        }
        MessageBox(0,"WM_USER","WM_USER",0);
        }
        if ( x == WM_LBUTTONDOWN)
        {
                d=WSAStartup(0x0101,&ws);
                sprintf(aa,"WSAStartup %ld",d);
                abc(aa);
                s=socket(AF_INET, SOCK_STREAM,0);
                sprintf(aa,"socket %ld",s);
                abc(aa);
                A.sin_family=AF_INET;
                A.sin_port = htons(80);
                A.sin_addr.s_addr =INADDR_ANY;
                d=bind(s,(struct sockaddr *) &A,sizeof(A));
                sprintf(aa,"bind %ld",d);
                abc(aa);
                WSAAsyncSelect(s,b,WM_USER+1,FD_ACCEPT|FD_READ);
                d=listen(s,100);
                sprintf(aa,"listen %ld",d);
                abc(aa);
                MessageBox(0,"hi","hi",0);
        }
        if ( x == WM_DESTROY)
                PostQuitMessage(0);
        return DefWindowProc(w,x,y,z);
}


