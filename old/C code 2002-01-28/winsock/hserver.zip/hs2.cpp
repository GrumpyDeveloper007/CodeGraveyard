#include <windows.h>
#include <stdio.h>
void abc(char *p)
{
        FILE *fp=fopen("z.txt","a+");
        fprintf(fp,"%s\n",p);
        fclose(fp);
}
WNDCLASS a;HWND b;MSG c;char aa[100];struct sockaddr_in A,A1;
WSAData ws;long d;SOCKET s,s1;int dw;
long _stdcall zzz (HWND,UINT,WPARAM,LPARAM);
int _stdcall WinMain(HINSTANCE i,HINSTANCE j,char *k,int l)
{
        a.lpszClassName="a1";
        a.hInstance=i;
        a.lpfnWndProc=zzz;
        a.hbrBackground=GetStockObject(WHITE_BRUSH);
        RegisterClass(&a);
        b=CreateWindow("a1","HTTP server",WS_OVERLAPPEDWINDOW,
                                                1,1,10,20,0,0,i,0);
        ShowWindow(b,3);
        while ( GetMessage(&c,0,0,0) )
                DispatchMessage(&c);
        return 1;
}
long _stdcall zzz (HWND w,UINT x,WPARAM y,LPARAM z)
{
        if ( x == WM_LBUTTONDOWN)
        {   
            d=WSAStartup(0x0101,&ws);
            sprintf(aa,"WSAStartup = %ld",d);
            abc(aa);
            MessageBox(0,aa,aa,0);
            s=socket(AF_INET,SOCK_STREAM,0);
            sprintf(aa,"socket = %ld",s);
            abc(aa);
            MessageBox(0,aa,aa,0);
            A.sin_family=AF_INET;
            A.sin_port = htons(80);
            A.sin_addr.s_addr = INADDR_ANY;
            d=bind(s,(struct sockaddr *)&A,sizeof(A));
            sprintf(aa,"bind = %ld",d);
            abc(aa);
            MessageBox(0,aa,aa,0);
            WSAAsyncSelect(s,b,WM_USER+1,FD_ACCEPT);
            d=listen(s,100);
            sprintf(aa,"listen = %ld",d);
            abc(aa);
            MessageBox(0,aa,aa,0);
            MessageBox(0,"hi","hi",0);
        }
        if (x==WM_USER+1)
        {        
                dw=sizeof(A1);
                s1=accept(s,(struct sockaddr *)&A1,&dw);
                sprintf(aa,"accept s1=%ld",s1);
                MessageBox(0,aa,aa,0);
                MessageBox(0,"In Accept","USER+1",0);
        }
        if ( x == WM_DESTROY)
                PostQuitMessage(0);
        return DefWindowProc(w,x,y,z);
}
