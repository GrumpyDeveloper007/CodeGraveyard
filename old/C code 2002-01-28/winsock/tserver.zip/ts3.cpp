#include <windows.h>
#include <winsock.h>
#include <stdio.h>

void abc(char *p)
{
        FILE *fp=fopen("z.txt","a+");
	fprintf(fp,"%s\n",p);
	fclose(fp);
}
WNDCLASS a;HWND b;MSG c;char aa[200];char bb[20000];char cc[2000];int xx;
long _stdcall zzz (HWND,UINT,WPARAM,LPARAM);
int _stdcall WinMain(HINSTANCE i,HINSTANCE j,char *k,int l)
{
	a.lpszClassName="a1";
	a.hInstance=i;
	a.lpfnWndProc=zzz;
	a.hbrBackground=GetStockObject(WHITE_BRUSH);
	RegisterClass(&a);
	b=CreateWindow("a1","In server",WS_OVERLAPPEDWINDOW,1,1,10,20,0,0,i,0);
	ShowWindow(b,3);
	while ( GetMessage(&c,0,0,0) )
		DispatchMessage(&c);
	return 1;
}
WSADATA ws;SOCKET s,s1,s2;sockaddr_in A,A1;int d,d1,d2,dd;
struct sockaddr_in B;
long _stdcall zzz (HWND w,UINT x,WPARAM y,LPARAM z)
{
	if (x == WM_USER+1)
	{
		strcpy(bb,"hello");
		d=sendto(s,bb,100,0,(sockaddr *)&A,sizeof(A));
		sprintf(aa,"in serv...d = %ld",d);
		abc(aa);
		MessageBox(0,aa,aa,0);
	}
	if ( x == WM_LBUTTONDOWN)
	{
		d=WSAStartup(0x0101,&ws);
		sprintf(aa,"d = %ld",d);
		abc(aa);
		s=socket(AF_INET, SOCK_DGRAM,0);
		sprintf(aa,"s = %ld",s);
		abc(aa);
		A.sin_family=AF_INET;
		A.sin_port = htons(13);
		A.sin_addr.s_addr =INADDR_ANY;
		d=bind(s,(struct sockaddr *) &A,sizeof(A));
		WSAAsyncSelect(s,b,WM_USER+1,FD_READ);
		int dw=sizeof(A);
		d=recvfrom(s,bb,100,0,(sockaddr *)&A,&dw);
		MessageBox(0,bb,"in server",0);
		abc(bb);
	}
	if ( x == WM_DESTROY)
		PostQuitMessage(0);
	return DefWindowProc(w,x,y,z);
}
