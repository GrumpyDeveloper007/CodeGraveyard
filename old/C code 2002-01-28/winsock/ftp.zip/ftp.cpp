#include <windows.h>
#include <winsock.h>
#include <stdio.h>
void abc(char *p)
{       FILE *fp=fopen("y.txt","a+");
        fprintf(fp,"%s\n",p);
        fclose(fp);
}
WNDCLASS a;HWND b;MSG c;char aa[200];char bb[20000];char cc[2000];int xx;
FILE *fpi;
long _stdcall zzz (HWND,UINT,WPARAM,LPARAM);
int _stdcall WinMain(HINSTANCE i,HINSTANCE j,char *k,int l)
{
        a.lpszClassName="a1";
        a.hInstance=i;
        a.lpfnWndProc=zzz;
        a.hbrBackground=GetStockObject(WHITE_BRUSH);
        RegisterClass(&a);
        b=CreateWindow("a1","aaa",WS_OVERLAPPEDWINDOW,1,1,10,20,0,0,i,0);
        ShowWindow(b,3);
        while ( GetMessage(&c,0,0,0) )
                DispatchMessage(&c);
        return 1;
}
WSADATA ws;SOCKET s,s1,s2;sockaddr_in A,A1;int d,d1,d2,dd;
struct sockaddr_in B;
long _stdcall zzz (HWND w,UINT x,WPARAM y,LPARAM z)
{
        if ( x == WM_USER+1)
        {
        if ( (LOWORD(z)&FD_ACCEPT) == FD_ACCEPT)
        { 
                d1=sizeof(A);
                accept(s1,(struct sockaddr *) &A,&d1);
                fpi=fopen("y.exe","wb");
                MessageBox(0,"Accept","WM_USER",0);
        }
        if ( (LOWORD(z)&FD_READ) == FD_READ)
        {
                d=recv(y,bb,sizeof(bb),0);
                abc(bb);
                for (d1=0;d1<d;d1++)
                fputc(bb[d1],fpi); 
                MessageBox(0,"Read","WM_USER",0);
        }
        if ( (LOWORD(z)&FD_CLOSE) == FD_CLOSE)
        {
                MessageBox(0,"CLOSE","WM_USER",0);
        }
        }
        if ( x == WM_LBUTTONDOWN)
        {
                d=WSAStartup(0x0101,&ws);
                s1=socket(AF_INET,SOCK_STREAM,0);
                A.sin_family=AF_INET;
                A.sin_port = htons(5135);
                A.sin_addr.s_addr =INADDR_ANY;
                d=bind(s1,(struct sockaddr *) &A,sizeof(A));
                sprintf(aa,"bind %d",d);
                abc(aa);
                d=listen(s1,1000);
                sprintf(aa,"listen %d",d);
                abc(aa);
                WSAAsyncSelect(s1,b,WM_USER+1,FD_READ|FD_ACCEPT|FD_CLOSE);
                s=socket(AF_INET,SOCK_STREAM,0);
                sprintf(aa,"socket %ld",s);
                abc(aa);
                A.sin_family=AF_INET;
                A.sin_port = htons(21);
                struct hostent *h = gethostbyname("ftp.microsoft.com");
                sprintf(aa,"gethostbyname %p..",h);
                abc(aa);
                A.sin_addr.s_addr =*(unsigned long *)h->h_addr_list[0];
                d=connect(s,(struct sockaddr *)&A,sizeof(A));
                sprintf(aa,"connect %d",d);
                abc(aa);
                d1=sizeof(A);
                d=getsockname(s,(struct sockaddr *)&A,&d1); 
                sprintf(aa,"getsockname %d",d);
                abc(aa);
                sprintf(cc,"PORT %d,%d,%d,%d,2,0",
                A.sin_addr.S_un.S_un_b.s_b1,A.sin_addr.S_un.S_un_b.s_b2,
                A.sin_addr.S_un.S_un_b.s_b3,A.sin_addr.S_un.S_un_b.s_b4);
                abc(cc);
                char *p=inet_ntoa(A.sin_addr);
                abc(p);
                d=recv(s,bb,sizeof(bb),0);
                bb[d]=0;
                sprintf(aa,"%d..%s",d,bb);
                abc(aa);
                strcpy(bb,"USER anonymous\r\n");
                d=send(s,bb,strlen(bb),0);
                sprintf(aa,"send %ld",d);
                abc(aa);
                d=recv(s,bb,sizeof(bb),0);
                bb[d]=0;
                sprintf(aa,"%d..%s",d,bb);
                abc(aa);
                strcpy(bb,"PASS v@eworld.com\r\n");
                d=send(s,bb,strlen(bb),0);
                sprintf(aa,"send %ld",d);
                abc(aa);
                d=recv(s,bb,sizeof(bb),0);
                bb[d]=0;
                sprintf(aa,"%d..%s",d,bb);
                abc(aa);
                strcpy(bb,"TYPE I \r\n");
                d=send(s,bb,strlen(bb),0);
                sprintf(aa,"send %ld",d);
                abc(aa);
                d=recv(s,bb,sizeof(bb),0);
                bb[d]=0;
                sprintf(aa,"%d..%s",d,bb);
                abc(aa);
                strcpy(bb,"PORT 202,54,3,53,20,15\r\n");
                d=send(s,bb,strlen(bb),0);
                sprintf(aa,"send %ld",d);
                abc(aa);                        
                d=recv(s,bb,sizeof(bb),0);
                bb[d]=0;
                sprintf(aa,"%d..%s",d,bb);
                abc(aa);
        /*
                strcpy(bb,"NLST\r\n");
                d=send(s,bb,strlen(bb),0);
                sprintf(aa,"send %ld",d);
                abc(aa);
        */
        strcpy(bb,"RETR /bussys/WinSock/WORMHOLE/MS-DOS/WORMHOLE.EXE\r\n");
        d=send(s,bb,strlen(bb),0);
        sprintf(aa,"send %ld",d);
        abc(aa);
        MessageBox(0,"hi","hi",0);
        fclose(fpi);
        }
        if ( x == WM_DESTROY)
                PostQuitMessage(0);
        return DefWindowProc(w,x,y,z);
}