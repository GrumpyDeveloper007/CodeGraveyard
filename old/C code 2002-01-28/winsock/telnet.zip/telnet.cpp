#include <windows.h>
#include <stdio.h>
void abc(char *p)
{
FILE *fp=fopen("z.txt","a+");
fprintf(fp,"%s\n",p);
fclose(fp);
}
WNDCLASS a;HWND b;MSG c;int d;char aa[100];char bb[100];
WSAData ws; SOCKET s;struct sockaddr_in A;int ii,jj;long gg;
char cc[4096];
char s1[3];char s2[11];char s3[2];
long _stdcall zzz (HWND,UINT,WPARAM,LPARAM);
int _stdcall WinMain(HINSTANCE i,HINSTANCE j,char *k,int l)
{
a.lpszClassName="a1";a.hInstance=i;a.lpfnWndProc=zzz;a.hbrBackground=GetStockObject(WHITE_BRUSH);
RegisterClass(&a);
b=CreateWindow("a1","aaa",WS_OVERLAPPEDWINDOW,1,1,10,20,0,0,i,0);
ShowWindow(b,3);
while ( GetMessage(&c,0,0,0) )
DispatchMessage(&c);
return 1;
}
long _stdcall zzz (HWND w,UINT x,WPARAM y,LPARAM z)
{
if ( x == WM_LBUTTONDOWN)
{       
gg=WSAStartup(0x0101,&ws);
sprintf(aa,"WSAStartup ..%ld",gg);
//abc(aa);
s = socket(AF_INET,SOCK_STREAM,0);
sprintf(aa,"socket s = %ld",s);
//abc(aa);
A.sin_family = AF_INET;
A.sin_port = htons(23);
A.sin_addr.s_addr = inet_addr("202.54.1.18");
d=connect(s,(struct sockaddr *)&A,sizeof(A));
sprintf(aa,"In Connect d = %ld",d);
//abc(aa);
s1[0]= 0xff;s1[1]=0xfb;s1[2]=0x18;
send(s,s1,3,0);
s1[0]= 0xff;s1[1]=0xfc;s1[2]=0x20;
send(s,s1,3,0);
s1[0]= 0xff;s1[1]=0xfc;s1[2]=0x23;
send(s,s1,3,0);
s1[0]= 0xff;s1[1]=0xfc;s1[2]=0x24;
send(s,s1,3,0);
ii=recv(s,cc,sizeof(cc),0);
for ( jj = 1;jj<= ii; jj++)
{
sprintf(aa,"%d..%c",cc[jj-1],cc[jj-1]);
//abc(aa);
}
s2[0]=0xff;s2[1]=0xfa;s2[2]=0x18;s2[3]=0x0;s2[4]=0x76;s2[5]=0x74;
s2[6]=0x31;s2[7]=0x30;s2[8]=0x30;s2[9]=0xff;s2[10]=0xf0;
send(s,s2,11,0);
ii=recv(s,cc,sizeof(cc),0);
for ( jj = 1;jj<= ii; jj++)
{
 sprintf(aa,"%d..%c",cc[jj-1],cc[jj-1]);
//abc(aa);
}
s1[0]= 0xff;s1[1]=0xfd;s1[2]=0x03;
send(s,s1,3,0);
s1[0]= 0xff;s1[1]=0xfb;s1[2]=0x01;
send(s,s1,3,0);
s1[0]= 0xff;s1[1]=0xfc;s1[2]=0x1f;
send(s,s1,3,0);
s1[0]= 0xff;s1[1]=0xfe;s1[2]=0x05;
send(s,s1,3,0);
s1[0]= 0xff;s1[1]=0xfc;s1[2]=0x21;
send(s,s1,3,0);
ii=recv(s,cc,sizeof(cc),0);
for ( jj = 1;jj<= ii; jj++)
{
sprintf(aa,"%d..%c",cc[jj-1],cc[jj-1]);
//abc(aa);
}
s1[0]= 0xff;s1[1]=0xfc;s1[2]=0x01;
send(s,s1,3,0);
s1[0]= 0xff;s1[1]=0xfd;s1[2]=0x01;
send(s,s1,3,0);
s1[0]= 0x76;
send(s,s1,1,0);
ii=recv(s,cc,sizeof(cc),0);
sprintf(aa,"Recv %d",ii);
//abc(aa);
for ( jj = 1;jj<= ii; jj++)
{
sprintf(aa,"%c",cc[jj-1]);
//abc(aa);
}


ii=recv(s,cc,sizeof(cc),0);
sprintf(aa,"First Recv %d",ii);
abc(aa);
for ( jj = 1;jj<= ii; jj++)
{
sprintf(aa,"%c",cc[jj-1]);
abc(aa);
}

send(s,"vmukhi",6,0);
s1[0]=0x0d;s1[1]=0x0a;
send(s,s1,2,0);
abc("send vmukhi");

ii=recv(s,cc,sizeof(cc),0);
sprintf(aa,"Second Recv %d",ii);
abc(aa);
for ( jj = 1;jj<= ii; jj++)
{
sprintf(aa,"%c",cc[jj-1]);
abc(aa);
}


ii=recv(s,cc,sizeof(cc),0);
sprintf(aa," third Recv %d",ii);
abc(aa);
for ( jj = 1;jj<= ii; jj++)
{
sprintf(aa,"%c",cc[jj-1]);
abc(aa);
}
ii=recv(s,cc,sizeof(cc),0);
sprintf(aa,"Recv %d",ii);
abc(aa);
for ( jj = 1;jj<= ii; jj++)
{
sprintf(aa,"%c",cc[jj-1]);
abc(aa);
}
send(s,"abc0101",8,0);
s1[0]=0x0d;s1[1]=0x0a;
send(s,s1,2,0);
abc("send password");
ii=recv(s,cc,sizeof(cc),0);
sprintf(aa,"Recv %d",ii);
abc(aa);
for ( jj = 1;jj<= ii; jj++)
{
sprintf(aa,"%c",cc[jj-1]);
abc(aa);
}
ii=recv(s,cc,sizeof(cc),0);
sprintf(aa,"Recv %d",ii);
abc(aa);
for ( jj = 1;jj<= ii; jj++)
{
sprintf(aa,"%c",cc[jj-1]);
abc(aa);
}
send(s,"vmukhi",6,0);
s1[0]=0x0d;s1[1]=0x0a;
send(s,s1,2,0);
abc("send vmukhi");
ii=recv(s,cc,sizeof(cc),0);
sprintf(aa,"Recv %d",ii);
abc(aa);
for ( jj = 1;jj<= ii; jj++)
{
sprintf(aa,"%c",cc[jj-1]);
abc(aa);
}
ii=recv(s,cc,sizeof(cc),0);
sprintf(aa,"Recv %d",ii);
abc(aa);
for ( jj = 1;jj<= ii; jj++)
{
sprintf(aa,"%c",cc[jj-1]);
abc(aa);
}
ii=recv(s,cc,sizeof(cc),0);
sprintf(aa,"Recv %d",ii);
abc(aa);
for ( jj = 1;jj<= ii; jj++)
{
sprintf(aa,"%c",cc[jj-1]);
abc(aa);
}
send(s,"abc0101",8,0);
s1[0]=0x0d;s1[1]=0x0a;
send(s,s1,2,0);
abc("send password");
ii=recv(s,cc,sizeof(cc),0);
sprintf(aa,"Recv %d",ii);
abc(aa);
for ( jj = 1;jj<= ii; jj++)
{
sprintf(aa,"%c",cc[jj-1]);
abc(aa);
}
ii=recv(s,cc,sizeof(cc),0);
sprintf(aa,"Recv %d",ii);
abc(aa);
for ( jj = 1;jj<= ii; jj++)
{
sprintf(aa,"%c",cc[jj-1]);
abc(aa);
}
s1[0]=0x0d;s1[1]=0x0a;
send(s,s1,2,0);
ii=recv(s,cc,sizeof(cc),0);
sprintf(aa,"Recv %d",ii);
abc(aa);
for ( jj = 1;jj<= ii; jj++)
{
sprintf(aa,"%c",cc[jj-1]);
abc(aa);
}
ii=recv(s,cc,sizeof(cc),0);
sprintf(aa,"Recv %d",ii);
abc(aa);
for ( jj = 1;jj<= ii; jj++)
{
sprintf(aa,"%c",cc[jj-1]);
abc(aa);
}


MessageBox(0,"hi in client","over",0);
}
if ( x == WM_DESTROY)
	PostQuitMessage(0);
return DefWindowProc(w,x,y,z);
}