#include <windows.h>
#include <stdio.h>
void abc(char *p){FILE *fp=fopen("c:\\z.txt","a+");fprintf(fp,"%s\n",p);fclose(fp);}
HMODULE i;char aa[1000];FARPROC a;DWORD d;



int (__stdcall *getsockopt1)(SOCKET ,int ,int ,char * , int * );
u_short (__stdcall *ntohs1)(u_short );
struct hostent *  (__stdcall *gethostbyname1)(const char FAR *  );
int (__stdcall *getsockname1)(SOCKET ,struct sockaddr *,int * );
int (__stdcall *bind1)(SOCKET ,const struct sockaddr *,int );
u_long (__stdcall *htonl1)(u_long);
char * (__stdcall *inet_ntoa1)(struct in_addr);
int (__stdcall *WsControl1)(int ,int ,int ,int ,int ,int );
unsigned long (__stdcall *inet_addr1)(const char FAR * );
int (__stdcall *__WSAFDIsSet1)(SOCKET,fd_set FAR *);
int (__stdcall *WSAGetLastError1)();
int (__stdcall *recv1)(SOCKET ,char FAR * ,int ,int );
int (__stdcall *send1)(SOCKET ,const char * ,int ,int);
int (__stdcall *connect1)(SOCKET,const struct sockaddr *,int);
int (__stdcall *closesockinfo1)(int );
int (__stdcall *NPLoadNameSpaces1)(int ,int ,int );
int (__stdcall *closesocket1)(SOCKET );
int (__stdcall *select1)(int ,fd_set FAR *,fd_set FAR *,fd_set FAR *,const struct timeval FAR * );
HANDLE  (__stdcall *WSAAsyncGetHostByName1)(HWND ,u_int ,const char FAR * , char FAR * ,int );
int (__stdcall *ioctlsocket1)(SOCKET ,long ,u_long FAR *);
int (__stdcall *setsockopt1)(SOCKET ,int ,int ,const char * ,int );
int (__stdcall *WSAAsyncSelect1)(SOCKET,HWND ,u_int,long);
SOCKET (__stdcall *socket1)(int ,int,int);
u_short (__stdcall *htons1)(u_short);
int	(__stdcall *WSAStartup1)(WORD,LPWSADATA);
int	(__stdcall *WSACleanup1)();

int PASCAL FAR WSAStartup(WORD wVersionRequired, LPWSADATA lpWSAData)
{
abc("WSAStartup");
i=LoadLibrary("c:\\windows\\system\\wsock32.aaa");
a=GetProcAddress(i,"WSAStartup");
WSAStartup1=(int (_stdcall *)(WORD,LPWSADATA))a;
return WSAStartup1(wVersionRequired,lpWSAData);

}
int PASCAL FAR WSACleanup(void)
{
abc("WSACleanup");
a=GetProcAddress(i,"WSACleanup");
WSACleanup1=(int (_stdcall *)())a;
return WSACleanup1();
}
u_short PASCAL FAR htons (u_short hostshort)
{
abc("htons");
a=GetProcAddress(i,"htons");
htons1=(u_short (_stdcall *)(u_short))a;
return htons1(hostshort);
}
SOCKET PASCAL FAR socket (int af, int type, int protocol)
{
abc("socket");
a=GetProcAddress(i,"socket");
socket1=(SOCKET (_stdcall *)(int ,int,int))a;
return socket1(af,type,protocol);
}
int PASCAL FAR WSAAsyncSelect(SOCKET s, HWND hWnd, u_int wMsg,long lEvent)
{
abc("WSAAsyncSelect");
a=GetProcAddress(i,"WSAAsyncSelect");
WSAAsyncSelect1=(int (_stdcall *)(SOCKET,HWND ,u_int,long ))a;
return WSAAsyncSelect1(s,hWnd,wMsg,lEvent);
}
int PASCAL FAR setsockopt(SOCKET s,int level,int optname,const char * optval,int optlen)
{
abc("setsockopt");
a=GetProcAddress(i,"setsockopt");
setsockopt1=(int (_stdcall *)(SOCKET ,int ,int ,const char * ,int ))a;
return setsockopt1(s,level,optname,optval,optlen);
}
int PASCAL FAR ioctlsocket(SOCKET s, long cmd, u_long FAR *argp)
{
abc("ioctlsocket");
a=GetProcAddress(i,"ioctlsocket");
ioctlsocket1=(int (_stdcall *)(SOCKET ,long ,u_long FAR *))a;
return ioctlsocket1(s,cmd,argp);
}
HANDLE PASCAL FAR WSAAsyncGetHostByName(HWND hWnd, u_int wMsg,const char FAR * name, char FAR * buf,int buflen)
{
abc("WSAAsyncGetHostByName");
a=GetProcAddress(i,"WSAAsyncGetHostByName");
WSAAsyncGetHostByName1=(HANDLE (_stdcall *)(HWND ,u_int ,const char FAR * , char FAR * ,int ))a;
return WSAAsyncGetHostByName1(hWnd,wMsg,name,buf,buflen);
}
int PASCAL FAR select(int nfds, fd_set FAR *readfds, fd_set FAR *writefds,fd_set FAR *exceptfds, const struct timeval FAR *timeout)
{
abc("select");
a=GetProcAddress(i,"select");
select1=(int (_stdcall *)(int ,fd_set FAR *,fd_set FAR *,fd_set FAR *,const struct timeval FAR *))a;
return select1(nfds,readfds,writefds,exceptfds,timeout);
}
int PASCAL FAR closesocket(SOCKET s)
{
abc("closesocket");
a=GetProcAddress(i,"closesocket");
closesocket1=(int (_stdcall *)(SOCKET ))a;
return closesocket1(s);
}
int PASCAL FAR NPLoadNameSpaces(int p,int q,int r)
{
abc("NPLoadNameSpaces");
a=GetProcAddress(i,"NPLoadNameSpaces");
NPLoadNameSpaces1=(int (_stdcall *)(int ,int ,int ))a;
return NPLoadNameSpaces1(p,q,r);
}
int PASCAL FAR closesockinfo(int p)
{
abc("closesockinfo");
a=GetProcAddress(i,"closesockinfo");
closesockinfo1=(int (_stdcall *)(int))a;
return closesockinfo1(p);
}
int PASCAL FAR connect(SOCKET s,const struct sockaddr *name, int namelen)
{
abc("connect");
a=GetProcAddress(i,"connect");
connect1=(int (_stdcall *)(SOCKET ,const struct sockaddr *,int ))a;
return connect1(s,name,namelen);
}
int PASCAL FAR WSAGetLastError(void)
{
a=GetProcAddress(i,"WSAGetLastError");
WSAGetLastError1=(int (_stdcall *)())a;
d=WSAGetLastError1();
sprintf(aa,"WSAGetLastError %d",d);
abc(aa);
return d;
}
int PASCAL FAR send(SOCKET s,const char * buf,int len,int flags)
{
abc("send");
a=GetProcAddress(i,"send");
send1=(int (_stdcall *)(SOCKET ,const char * ,int ,int ))a;
return send1(s,buf,len,flags);
}
int PASCAL FAR recv(SOCKET s, char FAR * buf, int len, int flags)
{
abc("recv");
a=GetProcAddress(i,"recv");
recv1=(int (_stdcall *)(SOCKET ,char FAR * ,int ,int ))a;
return recv1(s, buf, len, flags);
}
int PASCAL FAR __WSAFDIsSet(SOCKET p,fd_set FAR *q)
{
abc("__WSAFDIsSet");
a=GetProcAddress(i,"__WSAFDIsSet");
__WSAFDIsSet1=(int (_stdcall *)(SOCKET,fd_set FAR *))a;
return __WSAFDIsSet1(p,q);
}
unsigned long PASCAL inet_addr(const char FAR * cp)
{
abc("inet_addr");
a=GetProcAddress(i,"inet_addr");
inet_addr1=(unsigned long (_stdcall *)(const char FAR * ))a;
return inet_addr1(cp);
}
int PASCAL WsControl(int p,int q,int r,int s,int t,int u)
{
abc("WsControl");
a=GetProcAddress(i,"WsControl");
WsControl1=(int (_stdcall *)(int ,int ,int ,int ,int ,int ))a;
return WsControl1(p,q,r,s,t,u);
}
char * PASCAL inet_ntoa (struct in_addr in)
{
abc("inet_ntoa");
a=GetProcAddress(i,"inet_ntoa");
inet_ntoa1=(char *  (_stdcall *)(struct in_addr))a;
return inet_ntoa1(in);
}
u_long PASCAL FAR htonl(u_long hostlong)
{
abc("htonl");
a=GetProcAddress(i,"htonl");
htonl1=(u_long  (_stdcall *)(u_long))a;
return htonl1(hostlong);
}
int PASCAL bind(SOCKET s, const struct sockaddr FAR *addr, int namelen)
{
abc("bind");
a=GetProcAddress(i,"bind");
bind1=(int (_stdcall *)(SOCKET ,const struct sockaddr *,int ))a;
return bind1(s,addr,namelen);
}
int PASCAL getsockname(SOCKET s, struct sockaddr *name,int * namelen)
{
abc("getsockname");
a=GetProcAddress(i,"getsockname");
getsockname1=(int (_stdcall *)(SOCKET ,struct sockaddr *,int * ))a;
return getsockname1(s,name,namelen);
}
struct hostent * PASCAL FAR gethostbyname(const char FAR * name)
{
abc("gethostbyname");
a=GetProcAddress(i,"gethostbyname");
gethostbyname1=(struct hostent * (_stdcall *)(const char FAR * ))a;
return gethostbyname1(name);
}
u_short PASCAL ntohs(u_short netshort)
{
abc("ntohs");
a=GetProcAddress(i,"ntohs");
ntohs1=(u_short (_stdcall *)(u_short))a;
return ntohs1(netshort);
}
int PASCAL getsockopt(SOCKET s,int level,int optname,char * optval, int *optlen)
{
abc("getsockopt");
a=GetProcAddress(i,"getsockopt");
getsockopt1=(int (_stdcall *)(SOCKET ,int ,int ,char * , int *))a;
return getsockopt1(s,level,optname,optval,optlen);
}



SOCKET PASCAL FAR accept (SOCKET s, struct sockaddr FAR *addr,int FAR *addrlen){abc("1");return 0;}
int PASCAL FAR getpeername (SOCKET s, struct sockaddr FAR *name,int FAR * namelen){abc("5");return 0;}
int PASCAL FAR listen (SOCKET s, int backlog){abc("13");return 0;}
u_long PASCAL FAR ntohl (u_long netlong){abc("14");return 0;}
int PASCAL FAR recvfrom (SOCKET s, char FAR * buf, int len, int flags,struct sockaddr FAR *from, int FAR * fromlen){abc("17");return 0;}
int PASCAL FAR sendto (SOCKET s, const char FAR * buf, int len, int flags,const struct sockaddr FAR *to, int tolen){abc("20");return 0;}
int PASCAL FAR shutdown (SOCKET s, int how){abc("22");return 0;}
struct hostent FAR * PASCAL FAR gethostbyaddr(const char FAR * addr,int len, int type){abc("24");return 0;}
struct protoent FAR * PASCAL FAR getprotobynumber(int proto){abc("26");return 0;}
struct protoent FAR * PASCAL FAR getprotobyname(const char FAR * name){abc("27");return 0;}
struct servent FAR * PASCAL FAR getservbyport(int port, const char FAR * proto){abc("28");return 0;}
struct servent FAR * PASCAL FAR getservbyname(const char FAR * name,const char FAR * proto){abc("29");return 0;}
int PASCAL FAR gethostname (char FAR * name, int namelen){abc("30");return 0;}
HANDLE PASCAL FAR WSAAsyncGetServByName(HWND hWnd, u_int wMsg,const char FAR * name,const char FAR * proto,char FAR * buf, int buflen){abc("32");return 0;}
HANDLE PASCAL FAR WSAAsyncGetServByPort(HWND hWnd, u_int wMsg, int port,const char FAR * proto, char FAR * buf,int buflen){abc("33");return 0;}
HANDLE PASCAL FAR WSAAsyncGetProtoByName(HWND hWnd, u_int wMsg,const char FAR * name, char FAR * buf,int buflen){abc("34");return 0;}
HANDLE PASCAL FAR WSAAsyncGetProtoByNumber(HWND hWnd, u_int wMsg,int number, char FAR * buf,int buflen){abc("35");return 0;}
HANDLE PASCAL FAR WSAAsyncGetHostByAddr(HWND hWnd, u_int wMsg,const char FAR * addr, int len, int type,char FAR * buf, int buflen){abc("37");return 0;}
int PASCAL FAR WSACancelAsyncRequest(HANDLE hAsyncTaskHandle){abc("38");return 0;}
FARPROC PASCAL FAR WSASetBlockingHook(FARPROC lpBlockFunc){abc("39");return 0;}
int PASCAL FAR WSAUnhookBlockingHook(void){abc("40");return 0;}
void PASCAL FAR WSASetLastError(int iError){abc("41");}
int PASCAL FAR WSACancelBlockingCall(void){abc("43");return 0;}
BOOL PASCAL FAR WSAIsBlocking(void){abc("44");return 0;}
int PASCAL FAR WSARecvEx (SOCKET s, char FAR * buf, int len, int FAR *flags){abc("47");return 0;}
BOOL PASCAL FAR TransmitFile (IN SOCKET hSocket,IN HANDLE hFile,IN DWORD nNumberOfBytesToWrite,IN DWORD nNumberOfBytesPerSend,IN LPOVERLAPPED lpOverlapped,IN void *lpTransmitBuffers,IN DWORD dwReserved){abc("48");return 0;}

	  int PASCAL FAR Arecv (){abc("a3");return 0;}
	  int PASCAL FAR Asend (){abc("a4");return 0;}
	  int PASCAL FAR WSHEnumProtocols(){abc("a5");return 0;}
	  int PASCAL FAR inet_network (){abc("a6");return 0;}
	  int PASCAL FAR getnetbyname (){abc("a7");return 0;}
	  int PASCAL FAR rcmd  (){abc("a8");return 0;}
	  int PASCAL FAR rexec (){abc("a9");return 0;}
	  int PASCAL FAR rresvport (){abc("a10");return 0;}
	  int PASCAL FAR sethostname (){abc("a11");return 0;}
	  int PASCAL FAR dn_expand (){abc("a12");return 0;}
	  int PASCAL FAR s_perror  (){abc("a13");return 0;}
	  int PASCAL FAR GetAddressByNameA (){abc("a14");return 0;}
	  int PASCAL FAR GetAddressByNameW (){abc("a15");return 0;}
	  int PASCAL FAR EnumProtocolsA (){abc("a16");return 0;}
	  int PASCAL FAR EnumProtocolsW (){abc("a17");return 0;}
	  int PASCAL FAR GetTypeByNameA (){abc("a18");return 0;}
	  int PASCAL FAR GetTypeByNameW (){abc("a19");return 0;}
	  int PASCAL FAR GetNameByTypeA (){abc("a20");return 0;}
	  int PASCAL FAR GetNameByTypeW (){abc("a21");return 0;}
	  int PASCAL FAR SetServiceA (){abc("a22");return 0;}
	  int PASCAL FAR SetServiceW (){abc("a23");return 0;}
	  int PASCAL FAR GetServiceA (){abc("a24");return 0;}
	  int PASCAL FAR GetServiceW (){abc("a25");return 0;}



//BOOL PASCAL FAR AcceptEx (IN SOCKET sListenSocket,IN SOCKET sAcceptSocket,IN PVOID lpOutputBuffer,IN DWORD dwReceiveDataLength,IN DWORD dwLocalAddressLength,IN DWORD dwRemoteAddressLength,OUT LPDWORD lpdwBytesReceived,IN LPOVERLAPPED lpOverlapped){abc("1");return 0;}
//VOID PASCAL FAR GetAcceptExSockaddrs (IN PVOID lpOutputBuffer,IN DWORD dwReceiveDataLength,IN DWORD dwLocalAddressLength,IN DWORD dwRemoteAddressLength,OUT struct sockaddr **LocalSockaddr,OUT LPINT LocalSockaddrLength,OUT struct sockaddr **RemoteSockaddr,OUT LPINT RemoteSockaddrLength){abc("1");return 0;}

