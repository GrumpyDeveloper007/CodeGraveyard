Astro Travel  (Version 1.0)      
Web Site: http://www.galaxies.com
by Dean Salman

created using AppForge (www.appforge.com)


Contents of this readme file:
-----------------------------
* Program Description
* Contents of the Zip Archive
* Installation Instructions
* Using The Programs
* License and Distribution Details



Program Description:
--------------------
Astro Travel is reservation manager that allows you 
to mange your travel plans.  The program is divided into 
six sections air travel, car rentals, lodging, a to do list, 
program defaults, and tables. All travel information is tied
to a defined trip using the Trips Icon.

AppForge was used to create this program in Visual Basic and requires the AppForge
BOOSTER.PRC program to run.  This file is included but you should
check for updates at www.appforge.com



Contents of Zip Archive:
------------------------
readme.txt              -  This readme file
Userguide.doc	        -  A user guide for the program (Word 2000)
AstroTravel.PRC         -  The Palm Application (REQUIRED)

AT_Airlines_astb.PDB    -  Airlines database (REQUIRED)
AT_Airports_astb.PDB    -  City database (REQUIRED)
AT_Cars_astb.PDB        -  Car Rental Companies database (REQUIRED)
AT_Hotels_astb.PDB      -  Hotels database (REQUIRED)

AT_AirRes_astb.PDB      -  Air Travel Reservations database (REQUIRED)
AT_CarRes_astb.PDB      -  Car Rental Reservations database (REQUIRED)
AT_HotelRes_astb.PDB    -  Lodging Reservations database (REQUIRED)
AT_ToDo_astb.PDB        -  To Do List database (REQUIRED)
AT_Trips_astb.PDB       -  Defined Trips database (REQUIRED)
AT_System_astb.PDB      -  System database (REQUIRED)

Booster.Prc             -  This is the AppForge runtime engine required to run this program.



Installation Instructions:
--------------------------
Install all the PRC and all the PDB files as you would
any other Palm Application using the Install Tool.  You can also just
doulbe click on these files from Windows Explorer and perform a 
hot sync operation on the Palm.


Using The Programs:
--------------------------
Click on the Astro Travel icon on your Palm desktop.
See User Guide



License and Distribution Details:
---------------------------------
These files are freeware. You may feel free to distribute it IN ITS 
ORIGINAL STATE as you desire. However, you may not make changes to the original 
.pqa or .prc programs and then distribute the subsequent .pqa or .prc file as 
a different name, creator ID, or icon.


